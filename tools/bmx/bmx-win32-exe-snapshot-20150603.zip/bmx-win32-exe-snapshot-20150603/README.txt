This folder contains the following 32-bit Windows executables:
* bmx applications, bmxtranswrap.exe, mxf2raw.exe and raw2bmx.exe
* Quicktime file text dumper, movdump.exe
* h264 bitstream text dumper, h264dump.exe
* AAF SDK MXF file dumper, MXFDump.exe

See http://sourceforge.net/p/bmxlib for more information on bmx.

The git repository commit identifiers are as follows:
libMXF:   cb70230c451276b30c1290feb902331f18b753b7
libMXF++: 144fd1570598e37895bc62dcd5e22245c8105167
bmx:      664d2e36e95f22b8277301ee2840a14adaf7a99d


Microsoft Visual C++ 2010 Express was used to compile the applications. The
executables are dependent on the Visual C++ runtime libraries. If you
do not have Visual C++ 2010 installed, then you can download the
"Microsoft Visual C++ 2010 Redistributable Package (x86)"
from here: http://www.microsoft.com/en-gb/download/details.aspx?id=5555


2015-06-03
