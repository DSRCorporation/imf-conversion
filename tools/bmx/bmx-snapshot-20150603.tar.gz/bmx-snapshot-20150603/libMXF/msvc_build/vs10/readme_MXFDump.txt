MXFDump is a KLV/MXF file dumper and is provided by the AAF SDK
(http://aaf.sourceforge.net) in the AAF/DevUtils/MXFDump directory.

The following files were copied from the AAF SDK:

AAF/ref-impl/include/AAFMetaDictionary.h
AAF/DevUtils/MXFDump/MXFLabels.h
AAF/DevUtils/MXFDump/MXFMetaDictionary.h
AAF/DevUtils/MXFDump/MXFDump.h

