#define LIBMXF_SCM_VERSION "dpp-app-v1.2-30-gcb70230"
