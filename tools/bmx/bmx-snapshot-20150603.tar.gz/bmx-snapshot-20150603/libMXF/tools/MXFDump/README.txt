The following files were copied from the AAF SDK
(http://sourceforge.net/projects/aaf):

AAF/ref-impl/include/AAFMetaDictionary.h
AAF/DevUtils/MXFDump/MXFLabels.h
AAF/DevUtils/MXFDump/MXFMetaDictionary.h
AAF/DevUtils/MXFDump/MXFDump.cpp

