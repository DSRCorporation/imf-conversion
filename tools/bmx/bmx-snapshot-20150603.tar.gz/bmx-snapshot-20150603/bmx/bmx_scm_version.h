#define BMX_SCM_VERSION "dpp-app-v1.2-159-g664d2e3"
