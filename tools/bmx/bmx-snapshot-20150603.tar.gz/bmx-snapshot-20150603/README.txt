This packages contains a snapshot of the bmx source code. See
http://sourceforge.net/p/bmxlib for more information.

The git repository identifiers are as follows:
libMXF:   cb70230c451276b30c1290feb902331f18b753b7
libMXF++: 144fd1570598e37895bc62dcd5e22245c8105167
bmx:      664d2e36e95f22b8277301ee2840a14adaf7a99d

The expat and uriparser library source code is also included.
They were used to build the Windows executables.


2015-06-03
